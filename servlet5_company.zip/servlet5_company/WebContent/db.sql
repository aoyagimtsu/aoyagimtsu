drop table company_member;
create table company_member(
    member_idx       number(4) primary key,
    member_id      varchar2(20),
    member_pw     varchar2(20),
    member_name   varchar2(20),
    member_email   varchar2(100),
    member_email_receive   number(1),	--0: 비수신 1: 수신
    member_pw_question   number(4),
    member_pw_answer   varchar2(100),
    member_gender   varchar2(10),
    member_birth_date      date,
    member_join_date      date default sysdate
);

drop sequence company_member_seq;
create sequence company_member_seq;

insert into company_member(member_idx, member_id, member_pw, member_name, member_email, member_email_receive, member_pw_question, member_pw_answer, member_gender, member_birth_date, member_join_date) 
values (company_member_seq.nextval, 'hong', '1234', '홍길동', 'test@gmail.com', 0,0,0,'male','2000/01/01', sysdate);
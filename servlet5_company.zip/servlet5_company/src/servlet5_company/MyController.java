package servlet5_company;

import java.io.IOException;
import java.util.ArrayList;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(urlPatterns = { "/", "*.do" })
public class MyController extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doProcess(req, resp);
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doProcess(req, resp);
	}

	void doProcess(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		String requestURI = request.getRequestURI();
		int cmdIdx = requestURI.lastIndexOf("/") + 1;
		String command = requestURI.substring(cmdIdx); // "list.do"
		String jspPage = "";
		System.out.println("command:" + command);

		if (command.equals("") || command.equals("/")) {
			response.sendRedirect("/index.jsp");
		}
		else if (command.equals("member_join.do")) {
			String member_id = request.getParameter("member_id");
			String member_pw = request.getParameter("member_pw");
			String member_name = request.getParameter("member_name");
			String member_email_left = request.getParameter("member_email_left");
			String member_email_right = request.getParameter("member_email_right");
			String member_email_receive = request.getParameter("member_email_receive");
			String member_pw_question = request.getParameter("member_pw_question");
			String member_pw_answer = request.getParameter("member_pw_answer");
			String member_gender = request.getParameter("member_gender");
			String member_birth_date_year = request.getParameter("member_birth_date_year");
			String member_birth_date_month = request.getParameter("member_birth_date_month");
			String member_birth_date_day = request.getParameter("member_birth_date_day");

			System.out.println("id:" + member_id);
			System.out.println("pw:" + member_pw);
			System.out.println(member_name);
			System.out.println("mail:" + member_email_left);
			System.out.println("mail:" + member_email_right);
			System.out.println(member_email_receive);
			System.out.println("question:" + member_pw_question);
			System.out.println(member_pw_answer);
			System.out.println("gender:" + member_gender);
			System.out.println(member_birth_date_year);
			System.out.println(member_birth_date_month);
			System.out.println(member_birth_date_day);

			MemberDao.member_join(member_id, member_pw, member_name, member_email_left, member_email_right,
					member_email_receive, member_pw_question, member_pw_answer, member_gender, member_birth_date_year,
					member_birth_date_month, member_birth_date_day);

			RequestDispatcher dispatcher = request.getRequestDispatcher("/index.jsp");
			dispatcher.forward(request, response);
		} else if (command.equals("login.do")) {
			String member_id = request.getParameter("member_id");
			String member_pw = request.getParameter("member_pw");

			System.out.println("id:" + member_id);
			System.out.println("pw:" + member_pw);

			try {
				MemberDao.login(request);
			} catch (Exception e) {
				e.printStackTrace();
			}

			RequestDispatcher dispatcher = request.getRequestDispatcher("/index.jsp");
			dispatcher.forward(request, response);
		} else if (command.equals("idFind.do")) {
			try {
				String member_name = request.getParameter("member_name");
				String member_email = request.getParameter("member_email");
				System.out.println("name : " + member_name);
				System.out.println("email : " + member_email);

				MemberDao.idFind(request);
			} catch (Exception e) {
				e.printStackTrace();
			}

			RequestDispatcher dispatcher = request.getRequestDispatcher("/member/idFind.jsp");
			dispatcher.forward(request, response);
		}

		else if (command.equals("passwordFind.do")) {
			try {
				String member_name = request.getParameter("member_name");
				String member_id = request.getParameter("member_id");
				String member_email = request.getParameter("member_email");
				System.out.println("name : " + member_name);
				System.out.println("id : " + member_id);
				System.out.println("email : " + member_email);

				MemberDao.passwordFind(request);
			} catch (Exception e) {
				e.printStackTrace();
			}

			RequestDispatcher dispatcher = request.getRequestDispatcher("/member/passwordFind.jsp");
			dispatcher.forward(request, response);
		}

	}
}

package servlet5_company;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection {
	public static Connection getConnection() throws Exception {

		Connection conn = null;
		try {
			String user = "userid";
			String pw = "gh980105";
			String url = "jdbc:oracle:thin:@localhost:1521:xe";

			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn = DriverManager.getConnection(url, user, pw);

			System.out.println("Database가 연결되었습니다.");

		} catch (ClassNotFoundException cnfe) {
			System.out.println("DB 연결실패(ClassNotFoundException):" + cnfe.toString());
		} catch (SQLException sqle) {
			System.out.println("DB 연결실패(SQLException): " + sqle.toString());
		} catch (Exception e) {
			System.out.println("Unkonwn error");
			e.printStackTrace();
		}
		return conn;

	}
}
package servlet5_company;

import java.util.Date;

public class MemberDto {

	private int member_idx;
	private String member_id;
	private String member_pw;
	private String member_name;
	private String member_email_left;
	private String member_email_right;
	private int member_email_receive;
	private int member_pw_question;
	private String member_pw_answer;
	private String member_pw_gender;
	private int member_birth_date_year;
	private int member_birth_date_month;
	private int member_birth_date_day;
	private Date member_join_date;

	public MemberDto() {
	}

	public MemberDto(int member_idx, String member_id, String member_pw, String member_name, String member_email_left,
			String member_email_right, int member_email_receive, int member_pw_question, String member_pw_answer,
			String member_pw_gender, int member_birth_date_year, int member_birth_date_month, int member_birth_date_day,
			Date member_join_date) {
		super();
		this.member_idx = member_idx;
		this.member_id = member_id;
		this.member_pw = member_pw;
		this.member_name = member_name;
		this.member_email_left = member_email_left;
		this.member_email_right = member_email_right;
		this.member_email_receive = member_email_receive;
		this.member_pw_question = member_pw_question;
		this.member_pw_answer = member_pw_answer;
		this.member_pw_gender = member_pw_gender;
		this.member_birth_date_year = member_birth_date_year;
		this.member_birth_date_month = member_birth_date_month;
		this.member_birth_date_day = member_birth_date_day;
		this.member_join_date = member_join_date;
	}

	public int getMember_idx() {
		return member_idx;
	}

	public void setMember_idx(int member_idx) {
		this.member_idx = member_idx;
	}

	public String getMember_id() {
		return member_id;
	}

	public void setMember_id(String member_id) {
		this.member_id = member_id;
	}

	public String getMember_pw() {
		return member_pw;
	}

	public void setMember_pw(String member_pw) {
		this.member_pw = member_pw;
	}

	public String getMember_name() {
		return member_name;
	}

	public void setMember_name(String member_name) {
		this.member_name = member_name;
	}

	public String getMember_email_left() {
		return member_email_left;
	}

	public void setMember_email_left(String member_email_left) {
		this.member_email_left = member_email_left;
	}

	public String getMember_email_right() {
		return member_email_right;
	}

	public void setMember_email_right(String member_email_right) {
		this.member_email_right = member_email_right;
	}

	public int getMember_email_receive() {
		return member_email_receive;
	}

	public void setMember_email_receive(int member_email_receive) {
		this.member_email_receive = member_email_receive;
	}

	public int getMember_pw_question() {
		return member_pw_question;
	}

	public void setMember_pw_question(int member_pw_question) {
		this.member_pw_question = member_pw_question;
	}

	public String getMember_pw_answer() {
		return member_pw_answer;
	}

	public void setMember_pw_answer(String member_pw_answer) {
		this.member_pw_answer = member_pw_answer;
	}

	public String getMember_pw_gender() {
		return member_pw_gender;
	}

	public void setMember_pw_gender(String member_pw_gender) {
		this.member_pw_gender = member_pw_gender;
	}

	public int getMember_birth_date_year() {
		return member_birth_date_year;
	}

	public void setMember_birth_date_year(int member_birth_date_year) {
		this.member_birth_date_year = member_birth_date_year;
	}

	public int getMember_birth_date_month() {
		return member_birth_date_month;
	}

	public void setMember_birth_date_month(int member_birth_date_month) {
		this.member_birth_date_month = member_birth_date_month;
	}

	public int getMember_birth_date_day() {
		return member_birth_date_day;
	}

	public void setMember_birth_date_day(int member_birth_date_day) {
		this.member_birth_date_day = member_birth_date_day;
	}

	public Date getMember_join_date() {
		return member_join_date;
	}

	public void setMember_join_date(Date member_join_date) {
		this.member_join_date = member_join_date;
	}

}
